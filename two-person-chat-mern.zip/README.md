# Two-Person Chat (MERN)

Minimal, secure-ish chat for exactly two fixed users. Supports image/video uploads stored on the server.

## Quick start

### 1) Server
```bash
cd server
cp .env.example .env
# edit .env: set USER1_* and USER2_* and secrets
npm i
npm run seed   # creates/updates the two accounts
npm run dev
```

### 2) Client
```bash
cd client
npm i
npm run dev
```

- Open http://localhost:5173
- Login with the usernames/passwords you set in the server `.env`
- Chat, upload images/videos; media is private via signed links

## Deployment notes
- Run the server behind HTTPS (e.g., Nginx reverse proxy).
- Set `CLIENT_ORIGIN` in the server `.env` to your frontend URL.
- For production builds: `npm run build` in client and serve the static build separately, or place behind the same domain.
- The server enforces file type allowlist and size limit (`MAX_UPLOAD_MB`). Files stored under `UPLOAD_DIR` and referenced in MongoDB.
- Media is streamed through `/api/media/:id/stream?token=...` using a short‑lived signed token so `<video>`/`<img>` can load without Authorization headers.

## Tech
- Auth: bcrypt + JWT (+ rate limiting)
- Realtime: Socket.IO
- DB: MongoDB (Users, Messages, File metadata)
- Uploads: Multer to disk, streamed with Range support for videos
- UI: React + Vite + Tailwind; simple, clean, mobile‑friendly
