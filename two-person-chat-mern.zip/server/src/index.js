import 'dotenv/config'
import http from 'http'
import path from 'path'
import { fileURLToPath } from 'url'
import express from 'express'
import helmet from 'helmet'
import cors from 'cors'
import morgan from 'morgan'
import { Server } from 'socket.io'
import { connectDB } from './db.js'
import routes from './routes.js'
import { verifySocketAuth } from './socketAuth.js'
import { authRouter } from './auth.js'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const app = express()
app.set('trust proxy', 1)
app.use(helmet())
app.use(express.json({ limit: '2mb' }))
app.use(morgan('tiny'))

const CLIENT_ORIGIN = process.env.CLIENT_ORIGIN || 'http://localhost:5173'
app.use(cors({ origin: CLIENT_ORIGIN, credentials: true }))

// API routes
app.use('/api/auth', authRouter)
app.use('/api', routes)

// health
app.get('/health', (req, res) => res.json({ ok: true }))

// start HTTP + Socket.IO
const server = http.createServer(app)
const io = new Server(server, {
  cors: { origin: CLIENT_ORIGIN, methods: ['GET','POST'] }
})

// Socket authentication & room join (one room per username)
io.use(verifySocketAuth)
io.on('connection', socket => {
  const user = socket.user
  if (!user) return
  socket.join(user.username)

  socket.on('disconnect', () => {})
})

// Expose io on app for routes to emit
app.set('io', io)

const PORT = process.env.PORT || 4000
await connectDB()
server.listen(PORT, () => console.log(`[server] listening on :${PORT}`))
