import multer from 'multer'
import fs from 'fs'
import path from 'path'
import crypto from 'crypto'
import { File } from './models/File.js'

const uploadDir = process.env.UPLOAD_DIR || 'uploads'
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true })

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir)
  },
  filename: function (req, file, cb) {
    // temporary filename; we'll rename to ObjectId later
    cb(null, Date.now() + '-' + Math.round(Math.random() * 1e9))
  }
})

const allowed = new Set([
  'image/jpeg','image/png','image/gif','image/webp','image/heic','image/heif',
  'video/mp4','video/webm','video/ogg','video/quicktime','video/x-msvideo','video/x-matroska'
])

const maxSize = (Number(process.env.MAX_UPLOAD_MB || 200)) * 1024 * 1024

export const uploader = multer({
  storage,
  limits: { fileSize: maxSize },
  fileFilter: (req, file, cb) => {
    if (allowed.has(file.mimetype)) cb(null, true)
    else cb(new Error('Unsupported file type: ' + file.mimetype))
  }
})

export async function persistFile(file) {
  const hash = crypto.createHash('sha256')
  const data = fs.readFileSync(file.path)
  hash.update(data)
  const sha256 = hash.digest('hex')

  const doc = await File.create({
    originalName: file.originalname,
    mimeType: file.mimetype,
    size: file.size,
    path: file.path,
    sha256
  })

  // rename file to doc._id (for neatness)
  const ext = path.extname(file.originalname) || ''
  const newPath = path.join(path.dirname(file.path), String(doc._id) + ext)
  fs.renameSync(file.path, newPath)
  doc.path = newPath
  await doc.save()
  return doc
}
