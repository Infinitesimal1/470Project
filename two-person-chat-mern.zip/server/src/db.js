import mongoose from 'mongoose'

export async function connectDB() {
  const url = process.env.MONGO_URL
  if (!url) throw new Error('MONGO_URL is required')
  await mongoose.connect(url, { dbName: undefined })
  console.log('[db] connected')
}
