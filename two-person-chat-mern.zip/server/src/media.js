import jwt from 'jsonwebtoken'
import fs from 'fs'
import path from 'path'
import mime from 'mime-types'
import { File } from './models/File.js'

const MEDIA_SECRET = process.env.MEDIA_TOKEN_SECRET || 'media-secret'
const MEDIA_TTL = Number(process.env.MEDIA_TOKEN_TTL_SECONDS || 600)

export function signMediaToken(fileId) {
  return jwt.sign({ fid: String(fileId) }, MEDIA_SECRET, { expiresIn: MEDIA_TTL })
}

export function verifyMediaToken(token) {
  return jwt.verify(token, MEDIA_SECRET)
}

export async function streamMedia(req, res) {
  try {
    const { id } = req.params
    const token = req.query.token
    if (!token) return res.status(401).send('No token')
    const payload = verifyMediaToken(token)
    if (String(payload.fid) !== String(id)) return res.status(401).send('Invalid token')

    const file = await File.findById(id)
    if (!file) return res.status(404).send('Not found')

    const stat = fs.statSync(file.path)
    const range = req.headers.range
    const mimeType = file.mimeType || mime.lookup(path.extname(file.path)) || 'application/octet-stream'

    if (!range) {
      res.writeHead(200, {
        'Content-Type': mimeType,
        'Content-Length': stat.size,
        'Accept-Ranges': 'bytes',
        'Content-Disposition': /image\//.test(mimeType) ? 'inline' : 'inline'
      })
      fs.createReadStream(file.path).pipe(res)
      return
    }

    const parts = range.replace(/bytes=/, '').split('-')
    const start = parseInt(parts[0], 10)
    const end = parts[1] ? parseInt(parts[1], 10) : stat.size - 1
    const chunkSize = (end - start) + 1

    const fileStream = fs.createReadStream(file.path, { start, end })
    res.writeHead(206, {
      'Content-Range': `bytes ${start}-${end}/${stat.size}`,
      'Accept-Ranges': 'bytes',
      'Content-Length': chunkSize,
      'Content-Type': mimeType
    })
    fileStream.pipe(res)
  } catch (e) {
    res.status(401).send('Unauthorized')
  }
}
