import mongoose from 'mongoose'

const fileSchema = new mongoose.Schema({
  originalName: String,
  mimeType: String,
  size: Number,
  path: String,     // absolute or relative
  sha256: String
}, { timestamps: true })

export const File = mongoose.model('File', fileSchema)
