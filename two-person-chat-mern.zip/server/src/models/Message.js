import mongoose from 'mongoose'

const attachmentSchema = new mongoose.Schema({
  fileId: { type: mongoose.Schema.Types.ObjectId, ref: 'File', required: true },
  filename: String,
  mimeType: String,
  size: Number
}, { _id: false })

const messageSchema = new mongoose.Schema({
  from: { type: String, required: true },   // username
  to: { type: String, required: true },     // username
  text: { type: String, default: '' },
  attachments: [attachmentSchema],
}, { timestamps: true })

export const Message = mongoose.model('Message', messageSchema)
