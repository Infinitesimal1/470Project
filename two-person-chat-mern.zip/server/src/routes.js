import express from 'express'
import { requireAuth } from './auth.js'
import { uploader, persistFile } from './upload.js'
import { User } from './models/User.js'
import { Message } from './models/Message.js'
import { File } from './models/File.js'
import { signMediaToken, streamMedia } from './media.js'

const router = express.Router()

// Who am I
router.get('/me', requireAuth, async (req, res) => {
  const user = await User.findOne({ username: req.user.username }).lean()
  res.json({ user: { username: user.username, displayName: user.displayName }})
})

// Upload one or more files
router.post('/upload', requireAuth, uploader.array('files', 6), async (req, res) => {
  const out = []
  for (const file of req.files) {
    const doc = await persistFile(file)
    out.push({
      _id: doc._id,
      filename: doc.originalName,
      mimeType: doc.mimeType,
      size: doc.size
    })
  }
  res.json({ files: out })
})

// Create message (and emit)
router.post('/messages', requireAuth, async (req, res) => {
  const { to, text = '', attachments = [] } = req.body || {}
  if (!to) return res.status(400).json({ error: 'Missing "to"' })
  if (!text && (!attachments || !attachments.length)) {
    return res.status(400).json({ error: 'Empty message' })
  }

  // Prepare attachments
  const fileDocs = await File.find({ _id: { $in: attachments }}).lean()
  const att = fileDocs.map(f => ({
    fileId: f._id, filename: f.originalName, mimeType: f.mimeType, size: f.size
  }))

  const msg = await Message.create({
    from: req.user.username,
    to,
    text,
    attachments: att
  })

  // Emit to recipient room (and sender for echo)
  const io = req.app.get('io')
  io.to(to).emit('message:new', msg)
  io.to(req.user.username).emit('message:new', msg)

  res.json({ message: msg })
})

// Get conversation history with other user
router.get('/messages', requireAuth, async (req, res) => {
  const other = req.query.with
  if (!other) return res.status(400).json({ error: 'Missing "with"' })
  const username = req.user.username
  const msgs = await Message.find({
    $or: [{ from: username, to: other }, { from: other, to: username }]
  }).sort({ createdAt: 1 }).lean()
  res.json({ messages: msgs })
})

// Request a short-lived signed URL for an uploaded file
router.get('/media/:id/signed', requireAuth, async (req, res) => {
  const id = req.params.id
  const token = signMediaToken(id)
  res.json({ url: `/api/media/${id}/stream?token=${token}` })
})

// Stream endpoint (no auth header needed; token inside query)
router.get('/media/:id/stream', streamMedia)

export default router
