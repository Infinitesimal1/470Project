import 'dotenv/config'
import bcrypt from 'bcryptjs'
import { connectDB } from './src/db.js'
import { User } from './src/models/User.js'

async function main() {
  await connectDB()
  const u1 = process.env.USER1_NAME, p1 = process.env.USER1_PASSWORD
  const u2 = process.env.USER2_NAME, p2 = process.env.USER2_PASSWORD
  if (!u1 || !p1 || !u2 || !p2) {
    throw new Error('USER1_NAME/USER1_PASSWORD and USER2_NAME/USER2_PASSWORD are required')
  }
  const users = [
    { username: u1, displayName: u1, passwordHash: await bcrypt.hash(p1, 12) },
    { username: u2, displayName: u2, passwordHash: await bcrypt.hash(p2, 12) }
  ]
  for (const u of users) {
    const ex = await User.findOne({ username: u.username })
    if (ex) {
      ex.displayName = u.displayName
      ex.passwordHash = u.passwordHash
      await ex.save()
      console.log('[seed] updated', u.username)
    } else {
      await User.create(u)
      console.log('[seed] created', u.username)
    }
  }
  process.exit(0)
}
main().catch(e => { console.error(e); process.exit(1) })
