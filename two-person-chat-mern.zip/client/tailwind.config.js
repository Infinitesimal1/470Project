/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html','./src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#e6f6ff',
          100: '#ccecff',
          200: '#99daff',
          300: '#66c7ff',
          400: '#33b5ff',
          500: '#009fff',
          600: '#007acc',
          700: '#005899',
          800: '#003a66',
          900: '#001d33'
        }
      }
    }
  },
  plugins: [],
}
