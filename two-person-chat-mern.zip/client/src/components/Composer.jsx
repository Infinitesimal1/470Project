import React, { useState } from 'react'
import { uploadFiles, sendMessage } from '../api.js'
import { Image, Video, Send } from 'lucide-react'

export default function Composer({ me, peer, onSent }) {
  const [text, setText] = useState('')
  const [pending, setPending] = useState(false)
  const [files, setFiles] = useState([])

  const onPick = e => {
    const list = Array.from(e.target.files || [])
    setFiles(prev => [...prev, ...list])
    e.target.value = ''
  }

  const submit = async e => {
    e.preventDefault()
    if (pending) return
    setPending(true)
    try {
      let uploaded = []
      if (files.length) uploaded = await uploadFiles(files)
      const msg = await sendMessage({ to: peer.username, text, attachments: uploaded.map(f => f._id) })
      setText(''); setFiles([])
      onSent(msg)
    } finally {
      setPending(false)
    }
  }

  return (
    <form onSubmit={submit} className="p-3 border-t border-white/10 flex items-center gap-2">
      <label className="p-2 rounded-lg hover:bg-white/10 cursor-pointer">
        <input type="file" className="hidden" accept="image/*,video/*" multiple onChange={onPick} />
        <Image className="w-5 h-5" />
      </label>
      <label className="p-2 rounded-lg hover:bg-white/10 cursor-pointer">
        <input type="file" className="hidden" accept="video/*" multiple onChange={onPick} />
        <Video className="w-5 h-5" />
      </label>
      <input
        value={text}
        onChange={e=>setText(e.target.value)}
        placeholder="Type a message…"
        className="flex-1 bg-white/10 rounded-xl px-3 py-2 outline-none focus:ring-2 focus:ring-brand-400"
      />
      <button className="px-4 py-2 rounded-xl bg-brand-500 hover:bg-brand-600 flex items-center gap-2 disabled:opacity-50" disabled={pending || (!text && !files.length)}>
        <Send className="w-4 h-4" /> Send
      </button>
      {!!files.length && <div className="text-xs opacity-70">{files.length} file(s) attached</div>}
    </form>
  )
}
