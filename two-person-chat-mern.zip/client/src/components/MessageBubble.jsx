import React, { useEffect, useState } from 'react'
import { getSignedUrl, apiBase } from '../api.js'

export default function MessageBubble({ me, msg }) {
  const isMine = msg.from === me.username
  const [urls, setUrls] = useState([])

  useEffect(() => {
    let mounted = true
    ;(async () => {
      if (!msg.attachments?.length) { setUrls([]); return }
      const arr = []
      for (const att of msg.attachments) {
        const url = await getSignedUrl(att.fileId)
        arr.push({ ...att, url })
      }
      if (mounted) setUrls(arr)
    })()
    return ()=>{ mounted=false }
  }, [msg])

  return (
    <div className={`flex ${isMine ? 'justify-end' : 'justify-start'}`}>
      <div className={`max-w-[70%] rounded-2xl px-4 py-2 space-y-2 ${isMine ? 'bg-brand-600 text-white rounded-br-sm' : 'bg-white/10 rounded-bl-sm'}`}>
        {msg.text && <div className="whitespace-pre-wrap">{msg.text}</div>}
        {urls.map((att, i) => (
          <div key={i} className="rounded-xl overflow-hidden border border-white/10">
            {att.mimeType.startsWith('image/') ? (
              <img src={att.url} alt={att.filename} className="max-h-80 object-contain" />
            ) : att.mimeType.startsWith('video/') ? (
              <video src={att.url} controls className="max-h-80 w-full" />
            ) : (
              <a href={att.url} className="underline" target="_blank">{att.filename}</a>
            )}
          </div>
        ))}
        <div className="text-[10px] opacity-70">{new Date(msg.createdAt).toLocaleString()}</div>
      </div>
    </div>
  )
}
