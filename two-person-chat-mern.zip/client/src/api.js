import axios from 'axios'

const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:4000'

const axiosI = axios.create({
  baseURL: API_BASE,
  withCredentials: false
})

axiosI.interceptors.request.use(config => {
  const token = localStorage.getItem('token')
  if (token) config.headers.Authorization = 'Bearer ' + token
  return config
})

export async function login(username, password) {
  const { data } = await axiosI.post('/api/auth/login', { username, password })
  localStorage.setItem('token', data.token)
  return data
}

export async function getMe() {
  const token = localStorage.getItem('token')
  if (!token) return null
  const { data } = await axiosI.get('/api/me')
  return data
}

export async function fetchHistory(withUser) {
  const { data } = await axiosI.get('/api/messages', { params: { with: withUser }})
  return data.messages
}

export async function uploadFiles(files) {
  const fd = new FormData()
  for (const f of files) fd.append('files', f)
  const { data } = await axiosI.post('/api/upload', fd, {
    headers: { 'Content-Type': 'multipart/form-data' }
  })
  return data.files
}

export async function sendMessage(payload) {
  const { data } = await axiosI.post('/api/messages', payload)
  return data.message
}

export async function getSignedUrl(fileId) {
  const { data } = await axiosI.get(`/api/media/${fileId}/signed`)
  return data.url.startsWith('http') ? data.url : (API_BASE + data.url)
}

export function apiBase() { return API_BASE }
