import React, { useEffect, useMemo, useRef, useState } from 'react'
import io from 'socket.io-client'
import { apiBase, fetchHistory } from '../api.js'
import MessageBubble from '../components/MessageBubble.jsx'
import Composer from '../components/Composer.jsx'

export default function Chat({ me }) {
  const other = useMemo(() => ({ username: me.username === 'you' ? 'friend' : 'you', displayName: me.username === 'you' ? 'friend' : 'you' }), [me])
  const [messages, setMessages] = useState([])
  const listRef = useRef(null)

  useEffect(() => {
    ;(async () => {
      const history = await fetchHistory(other.username)
      setMessages(history)
      setTimeout(() => { listRef.current?.lastElementChild?.scrollIntoView({ behavior: 'instant' }) }, 0)
    })()
  }, [other.username])

  useEffect(() => {
    const token = localStorage.getItem('token')
    const socket = io(apiBase(), { auth: { token } })
    socket.on('connect', () => {})
    socket.on('message:new', msg => {
      setMessages(prev => [...prev, msg])
      setTimeout(() => { listRef.current?.lastElementChild?.scrollIntoView({ behavior: 'smooth' }) }, 10)
    })
    return () => socket.disconnect()
  }, [])

  return (
    <div className="min-h-screen grid grid-rows-[auto,1fr,auto]">
      <header className="p-4 border-b border-white/10 backdrop-blur bg-black/20 flex items-center justify-between">
        <div className="font-semibold">{other.displayName}</div>
        <div className="text-xs opacity-70">Signed in as {me.username}</div>
      </header>
      <main ref={listRef} className="p-4 space-y-3 overflow-y-auto scrollbar-thin">
        {messages.map(m => <MessageBubble key={m._id} me={me} msg={m} />)}
      </main>
      <Composer me={me} peer={other} onSent={(m)=>setMessages(prev=>[...prev, m])} />
    </div>
  )
}
