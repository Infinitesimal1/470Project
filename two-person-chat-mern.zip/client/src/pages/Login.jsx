import React, { useState } from 'react'
import { login } from '../api.js'
import { Lock, LogIn } from 'lucide-react'

export default function Login({ onLogin }) {
  const [username, setUsername] = useState('you')
  const [password, setPassword] = useState('')
  const [error, setError] = useState(null)
  const [loading, setLoading] = useState(false)

  const submit = async e => {
    e.preventDefault()
    setError(null); setLoading(true)
    try {
      const { user } = await login(username, password)
      onLogin(user)
    } catch (e) {
      setError(e?.response?.data?.error || 'Login failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen grid place-items-center bg-gradient-to-br from-brand-900 via-slate-900 to-brand-800">
      <form onSubmit={submit} className="glass w-full max-w-md rounded-2xl p-8 space-y-4">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-xl bg-white/10"><Lock /></div>
          <h1 className="text-2xl font-semibold">Two-Person Chat</h1>
        </div>
        <div className="space-y-2">
          <label className="text-sm text-slate-300">Username</label>
          <input value={username} onChange={e=>setUsername(e.target.value)}
            className="w-full bg-white/10 border border-white/10 rounded-xl px-4 py-2 outline-none focus:ring-2 focus:ring-brand-400"
            placeholder="you or friend" autoFocus />
        </div>
        <div className="space-y-2">
          <label className="text-sm text-slate-300">Password</label>
          <input type="password" value={password} onChange={e=>setPassword(e.target.value)}
            className="w-full bg-white/10 border border-white/10 rounded-xl px-4 py-2 outline-none focus:ring-2 focus:ring-brand-400"
            placeholder="••••••••" />
        </div>
        {error && <div className="text-sm text-red-300">{error}</div>}
        <button disabled={loading} className="w-full rounded-xl bg-brand-500 hover:bg-brand-600 py-2 font-medium flex items-center justify-center gap-2">
          <LogIn className="w-4 h-4" /> {loading ? 'Signing in…' : 'Sign in'}
        </button>
        <p className="text-xs text-slate-400">Only two fixed accounts exist (set in server .env)</p>
      </form>
    </div>
  )
}
