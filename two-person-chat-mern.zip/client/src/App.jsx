import React, { useEffect, useState } from 'react'
import Login from './pages/Login.jsx'
import Chat from './pages/Chat.jsx'
import { getMe } from './api.js'

export default function App() {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    (async () => {
      try {
        const me = await getMe()
        setUser(me?.user || null)
      } catch {}
      setLoading(false)
    })()
  }, [])

  if (loading) return <div className="min-h-screen grid place-items-center">Loading…</div>
  if (!user) return <Login onLogin={setUser} />
  return <Chat me={user} />
}
